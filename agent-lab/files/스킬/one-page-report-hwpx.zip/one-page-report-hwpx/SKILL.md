---
name: one-page-report-hwpx
description: >
  한 장 보고서 hwpx 양식을 자동으로 채워 완성된 hwpx 파일로 출력한다.
  사용자가 주제 또는 hwpx 파일을 업로드하면 개요·본문·결론을 양식 구조에 맞게 작성한다.
  "보고서 양식 채워줘", "한 장 보고서 작성해줘", "hwpx 자동완성" 요청 시 반드시 이 스킬을 사용한다.
---

# 한 장 보고서 자동 작성 스킬

## 개요

사용자가 제공한 주제와 hwpx 양식 파일을 기반으로 보고서를 자동 작성한다.
hwpx 파일은 ZIP 기반 포맷이며, `Contents/section0.xml` 내 `<hp:t>` 노드를 인덱스 기반으로 치환한다.
사용자가 자료(PDF, 텍스트, 통계 등)를 함께 제공하면 Quality가 높은 보고서를 생성할 수 있다.

---

## 양식 파일 정보

| 항목 | 내용 |
|------|------|
| 파일명 | `one_page_보고서_양식.hwpx` |
| BinData | 없음 |
| section0.xml hp:t 노드 수 | 총 19개 |
| 구성 | 제목 / 개요 / 본문(실행계획·분석1~3·해결방안) / 결론 / 참고문헌 |

---

## hp:t 인덱스 매핑 (검증 완료)

| 인덱스 | 원본 플레이스홀더 | 역할 | 작성 지침 |
|--------|----------------|------|----------|
| 000 | `None` | 빈 노드 | 수정 금지 |
| 001 | `제목: 000 보고서 양식` | **보고서 제목** | 주제를 반영한 제목으로 교체 |
| 002 | `폰트 HY헤드라인M, 크기 20` | 안내 텍스트 | **빈 문자열(`''`)로 제거 (필수)** |
| 003 | `None` | 빈 노드 | 수정 금지 |
| 004 | `개요 or 서론 ` | 개요 헤더 | `'개요'` 유지 |
| 005 | `(본 문서를 한 페이지로 나타내기 위한 내용 작성 1줄 또는 2줄 이내)` | **개요 내용** | 핵심 내용 1~2줄 요약 (반드시 2줄 이내) |
| 006 | `본문` | 본문 헤더 | `'본문'` 유지 |
| 007 | `[실행계획]` | **실행계획** | 추진 방향 및 단계 기술 |
| 008 | `[분석1] ` | **분석1** | 소제목 포함, 첫 번째 분석 항목 |
| 009 | `[분석2] ` | **분석2** | 소제목 포함, 두 번째 분석 항목 |
| 010 | `[분석3] ` | **분석3** | 소제목 포함, 세 번째 분석 항목 |
| 011 | `[해결방안]` | **해결방안** | 문제 해결 방향 및 제안 |
| 012 | `\ufeff` | BOM 노드 | 수정 금지 |
| 013 | `결론` | 결론 헤더 | `'결론'` 유지 |
| 014 | `본문에 따른 방향제시 및 결과` | **결론 요약** | 방향 제시 및 핵심 결론 1~2줄 |
| 015 | `내용1` | **결론 세부1** | 단기 방향 또는 시사점 |
| 016 | `내용2` | **결론 세부2** | 중장기 방향 또는 기대 효과 |
| 017 | `참고문헌` | 참고문헌 헤더 | `'참고문헌'` 유지 |
| 018 | `논문명 / 기사 / 사이트 작성` | **참고문헌 목록** | 사용자 제공 자료 우선 기재 |

---

## 작성 규칙

- 개요는 반드시 **1~2줄 이내**
- 본문 순서 고정: 실행계획 → 분석1 → 분석2 → 분석3 → 해결방안
- 결론 세부내용은 정확히 **2개**
- 전체 분량: **한 페이지 이내**
- 문체: 공식적·간결체 (개조식 허용)
- 이모지 사용 금지 (hwpx 렌더링 시 깨짐)

---

## Quality 기준

사용자가 자료를 제공할수록 아래 기준의 충족도가 높아진다.

| 기준 | 적용 방법 |
|------|----------|
| **Accuracy (정확성)** | 사용자 제공 수치·사실을 그대로 반영 |
| **Reliability (신뢰성)** | 출처 명시, 검증된 기관 자료 우선 사용 |
| **Timeliness (최신성)** | 가장 최근 연도 데이터 반영 |
| **Relevance (맥락 적합성)** | 보고서 목적·독자에 맞게 내용 선별 |
| **Consistency (일관성)** | 수치·용어·논리 흐름 통일 |
| **Completeness (완결성)** | 6개 본문 섹션 + 결론 누락 없이 작성 |

---

## 실행 절차

### 1단계: hwpx 파일 압축 해제

```python
import zipfile, os, shutil
from lxml import etree

hwpx_path = "/mnt/user-data/uploads/one_page_보고서_양식.hwpx"
extract_dir = "/home/claude/hwpx_work"

shutil.rmtree(extract_dir, ignore_errors=True)
os.makedirs(extract_dir)

with zipfile.ZipFile(hwpx_path, 'r') as z:
    z.extractall(extract_dir)
```

### 2단계: hp:t 인덱스 확인 (반드시 실행)

```python
section_path = f"{extract_dir}/Contents/section0.xml"
tree = etree.parse(section_path)
root = tree.getroot()
HP = 'http://www.hancom.co.kr/hwpml/2011/paragraph'

for i, t in enumerate(root.iter(f'{{{HP}}}t')):
    print(f'[{i:03d}] {repr(t.text)}')
```

### 3단계: 콘텐츠 초안 생성

치환 전, 아래 형식으로 내용을 먼저 생성한다. (사용자 확인 또는 바로 4단계 진행)

```
[제목] 주제에 맞는 보고서 제목

[개요] 핵심 내용 1~2줄 요약

[실행계획] 추진 방향 및 단계

[분석1] 소제목: 내용
[분석2] 소제목: 내용
[분석3] 소제목: 내용

[해결방안] 문제 해결 방향

[결론] 방향 제시 및 결과
- 세부내용1
- 세부내용2

[참고문헌] 출처 목록
```

### 4단계: 인덱스 기반 텍스트 치환

⚠️ **텍스트 매칭(str.replace) 방식 절대 사용 금지. 반드시 인덱스로 치환.**

```python
parser = etree.XMLParser(remove_blank_text=False)
tree = etree.parse(section_path, parser)
root = tree.getroot()
HP = 'http://www.hancom.co.kr/hwpml/2011/paragraph'

t_nodes = list(root.iter(f'{{{HP}}}t'))

replacements = {
    1:  '[생성된 보고서 제목]',
    2:  '',                        # 안내 텍스트 제거 (필수)
    4:  '개요',
    5:  '[생성된 개요 내용]',
    6:  '본문',
    7:  '[생성된 실행계획]',
    8:  '[생성된 분석1]',
    9:  '[생성된 분석2]',
    10: '[생성된 분석3]',
    11: '[생성된 해결방안]',
    13: '결론',
    14: '[생성된 결론]',
    15: '[생성된 세부내용1]',
    16: '[생성된 세부내용2]',
    17: '참고문헌',
    18: '[생성된 참고문헌]',
}

for idx, new_text in replacements.items():
    if idx < len(t_nodes):
        t_nodes[idx].text = new_text
```

### 5단계: linesegarray 초기화 (글자 겹침 방지)

```python
for lsa in root.iter(f'{{{HP}}}linesegarray'):
    for child in list(lsa):
        lsa.remove(child)

tree.write(section_path, xml_declaration=True, encoding='UTF-8', standalone=True)
```

### 6단계: hwpx 재압축 및 출력

```python
output_path = "/mnt/user-data/outputs/완성_한장보고서.hwpx"

with zipfile.ZipFile(output_path, 'w') as zout:
    zout.write(os.path.join(extract_dir, 'mimetype'), 'mimetype',
               compress_type=zipfile.ZIP_STORED)
    for root_dir, dirs, files in os.walk(extract_dir):
        for file in files:
            file_path = os.path.join(root_dir, file)
            arcname = os.path.relpath(file_path, extract_dir)
            if arcname == 'mimetype':
                continue
            zout.write(file_path, arcname, compress_type=zipfile.ZIP_DEFLATED)

print("완료:", output_path)
```

완료 후 반드시 `present_files`로 사용자에게 다운로드 링크를 제공한다.

---

## 주의사항

| 규칙 | 이유 |
|------|------|
| 인덱스 기반 치환만 사용 | 동일 패턴 셀 연쇄 덮어쓰기 버그 방지 |
| linesegarray 반드시 초기화 | 긴 텍스트 삽입 후 글자 겹침 방지 |
| mimetype은 ZIP_STORED로 첫 번째 저장 | hwpx 포맷 규격 준수 |
| header.xml 스타일 ID 변경 금지 | 서식 깨짐 방지 |
| 이모지 사용 금지 | hwpx 렌더링 오류 발생 |
| 작업 전 extract_dir 초기화 | 이전 파일 오염 방지 |
| 2단계 인덱스 확인 항상 실행 | 양식 버전 차이 오류 방지 |
| 인덱스 000·003·012 수정 금지 | None/BOM 노드 — 수정 시 구조 손상 |

---

## 사용자 안내 (스킬 시작 시)

hwpx 파일 또는 주제를 받으면 아래를 확인한다:

1. **보고서 주제** (필수)
2. **보고서 제목** (없으면 주제 기반 자동 생성)
3. **작성 목적 / 대상 독자** (선택 — 없으면 일반 공식 보고서로 작성)
4. **강조할 분석 항목** (선택)
5. **참고 자료** (PDF, 엑셀, 텍스트 등 — 첨부 시 Quality 향상)

※ 입력하지 않은 항목은 주제 기반으로 자동 작성됩니다.
※ 자료를 함께 제공할수록 Accuracy·Reliability·Timeliness·Relevance·Consistency·Completeness 가 높아집니다.
